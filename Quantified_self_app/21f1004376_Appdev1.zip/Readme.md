#This is a Readme file for the steps to be followed to run App Dev Project 1

1) You will have to install all the dependent libraries from the file requirements.txt I have pip freeze so that you can get more than just depenent libraries.

2) If you are running the app online on replit make sure Host is set to "0.0.0.0".

3) Download sqlite3 studio and connect the database to review entries and backend validations.

4) After running the app on offline/online IDE make sure to follow the link provided through Flask to access the app.

5)If you are using the app for first time, sign up and login after that you can use all the functionalities of the web app smoothly. 